<h1 align="center"> Pokémon Database Search </h1>

<p align="center"><img src="img/Pokemon Database Search.png" alt="Image" height="308" width="1024"/></p>

Trabalho do curso a ser mostrado no dia 12/11/2024. É um buscador simples de todos os pokémons de todas as gerações, além de mostrar a carta no TCG.

### APIs Utilizadas
- PokéAPI: https://pokeapi.co
- PokémonTCG: https://pokemontcg.io

### Linguagens Utilizadas
- PHP
- CSS
- JavaScript
